package com.cloud.project1.service;

public interface LoadBalancerService {

	public void scaleInscaleOut();
}
