#!/bin/bash
cd /home/ubuntu/
java -jar /home/ubuntu/listener-running-0.0.1-SNAPSHOT.jar
