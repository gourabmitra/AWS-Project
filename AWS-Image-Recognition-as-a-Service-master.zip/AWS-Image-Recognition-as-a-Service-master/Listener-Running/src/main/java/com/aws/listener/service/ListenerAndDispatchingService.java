package com.aws.listener.service;

public interface ListenerAndDispatchingService {
	
	public void generalFunction();

}
