package com.aws.listener.service;

public interface S3Service {
	
	public void putObject(String key, String value);

}
