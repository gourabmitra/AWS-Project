package com.aws.listener.service;

public interface Ec2Service {
	
	public void endInstance();

}
