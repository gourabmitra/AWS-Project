package com.aws.listener.repo;

public interface Ec2Repo {
	
	public void endInstance();

}
